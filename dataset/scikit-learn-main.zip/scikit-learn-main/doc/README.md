# Documentation for scikit-learn

This directory contains the full manual and website as displayed at
https://scikit-learn.org. See
https://scikit-learn.org/dev/developers/contributing.html#documentation for
detailed information about the documentation.
