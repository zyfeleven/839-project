.. _general_examples:

Examples
========

This is the gallery of examples that showcase how scikit-learn can be used. Some
examples demonstrate the use of the :ref:`API <api_ref>` in general and some
demonstrate specific applications in tutorial form. Also check out our
:ref:`user guide <user_guide>` for more detailed illustrations.
