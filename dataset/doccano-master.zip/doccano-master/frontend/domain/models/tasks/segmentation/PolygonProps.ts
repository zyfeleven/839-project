export default interface PolygonProps {
  id: string
  label: number
  points: number[]
}
