export default interface RectangleProps {
  id: string
  x: number
  y: number
  width: number
  height: number
  label: number
}
