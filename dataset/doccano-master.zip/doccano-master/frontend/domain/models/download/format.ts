export class Format {
  name: string
  example: string
  properties: object
}
