export default {
  createLink: 'Create Link',
  linkName: 'Link name',
  linkMessage: 'Link name is required'
}
