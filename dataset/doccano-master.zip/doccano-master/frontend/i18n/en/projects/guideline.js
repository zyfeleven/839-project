export default {
  guideline: 'Guideline',
  writeGuidelinePrompt: 'Please write annotation guideline.'
}
