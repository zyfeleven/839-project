export default {
  statistics: 'Metrics',
  progress: ['Completed', 'Incomplete'],
  labelStats: 'Label stats',
  userStats: 'User stats'
}
