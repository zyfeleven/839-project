export default {
  localeCode: 'de_DE'
}
