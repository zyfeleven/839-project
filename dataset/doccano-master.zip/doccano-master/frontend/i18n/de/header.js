export default {
  projects: 'Projekte'
}
