export default {
  labels: 'Labels',
  shortkey: 'Tastenkürzel',
  color: 'Farbe',
  createLabel: 'Erstelle Label',
  importLabels: 'Importiere Labels',
  exportLabels: 'Exportiere Labels',
  labelName: 'Labelname',
  labelMessage: 'Labelname wird benötigt',
  createLink: 'Create Link',
  key: 'Schlüssel',
  deleteLabel: 'Lösche Label',
  deleteMessage: 'Bist du dir sicher, dass du diese Labels aus dem Projekt löschen willst?',
  importTitle: 'Label hochladen',
  importMessage1: 'Beispielformat',
  importMessage2: 'Wähle eine Datei',
  filePlaceholder: 'Eingabe einer Datei'
}
