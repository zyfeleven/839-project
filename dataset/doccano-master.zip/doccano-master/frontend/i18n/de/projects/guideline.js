export default {
  guideline: 'Leitfaden',
  writeGuidelinePrompt: 'Bitte schreib einen Annotationsleitfaden.'
}
