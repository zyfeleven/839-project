declare module '*.txt'
declare module '*.jsonl'
declare module '*.csv'
