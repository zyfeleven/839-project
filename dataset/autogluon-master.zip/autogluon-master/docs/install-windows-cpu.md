:::{note}

```{include} install-windows-generic.md
```

```bash
conda create -n myenv python=3.11 -y
conda activate myenv
```

4. Continue with the remaining installation steps using the conda environment created above

:::
