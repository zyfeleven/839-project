Available Documentation for AutoGluon
-------------------------------------

Web-based documentation is available for versions listed below:

- `AutoGluon 1.1.2 (dev) documentation <https://auto.gluon.ai/dev/index.html>`_
- `AutoGluon 1.1.1 (stable) documentation <https://auto.gluon.ai/stable/index.html>`_
- `AutoGluon 1.1.0 documentation <https://auto.gluon.ai/1.1.0/index.html>`_
- `AutoGluon 1.0.0 documentation <https://auto.gluon.ai/1.0.0/index.html>`_
- `AutoGluon 0.8.2 documentation <https://auto.gluon.ai/0.8.2/index.html>`_
- `AutoGluon 0.8.1 documentation <https://auto.gluon.ai/0.8.1/index.html>`_
- `AutoGluon 0.8.0 documentation <https://auto.gluon.ai/0.8.0/index.html>`_
- `AutoGluon 0.7.0 documentation <https://auto.gluon.ai/0.7.0/index.html>`_
- `AutoGluon 0.6.2 documentation <https://auto.gluon.ai/0.6.2/index.html>`_
- `AutoGluon 0.6.1 documentation <https://auto.gluon.ai/0.6.1/index.html>`_
- `AutoGluon 0.6.0 documentation <https://auto.gluon.ai/0.6.0/index.html>`_
- `AutoGluon 0.5.2 documentation <https://auto.gluon.ai/0.5.2/index.html>`_
- `AutoGluon 0.5.1 documentation <https://auto.gluon.ai/0.5.1/index.html>`_
- `AutoGluon 0.4.2 documentation <https://auto.gluon.ai/0.4.2/index.html>`_
- `AutoGluon 0.4.1 documentation <https://auto.gluon.ai/0.4.1/index.html>`_
- `AutoGluon 0.4.0 documentation <https://auto.gluon.ai/0.4.0/index.html>`_
- `AutoGluon 0.3.1 documentation <https://auto.gluon.ai/0.3.1/index.html>`_
- `AutoGluon 0.3.0 documentation <https://auto.gluon.ai/0.3.0/index.html>`_
- `AutoGluon 0.2.0 documentation <https://auto.gluon.ai/0.2.0/index.html>`_
- `AutoGluon 0.1.0 documentation <https://auto.gluon.ai/0.1.0/index.html>`_
- `AutoGluon 0.0.15 (legacy) documentation <https://auto.gluon.ai/0.0.15/index.html>`_
