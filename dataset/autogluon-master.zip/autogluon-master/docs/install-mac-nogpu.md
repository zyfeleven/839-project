:::{warning} 

GPU usage is not yet supported on macOS, please use Linux or Windows to utilize GPUs in AutoGluon.

:::
