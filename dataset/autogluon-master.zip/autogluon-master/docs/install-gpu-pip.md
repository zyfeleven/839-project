```console
pip install -U pip
pip install -U setuptools wheel
pip install -U uv
uv pip install autogluon
```

